#!/bin/sh
java  -jar ScriptMonkey.jar
        